import { RedisDumpClient } from "@/components/admin/RedisDumpClient"

export default function RedisDumpPage() {
  return <RedisDumpClient />
}
