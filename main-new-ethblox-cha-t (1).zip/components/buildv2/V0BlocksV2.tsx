"use client"
import V0Blocks from "@/components/build/V0Blocks"
import { useState, useEffect, useMemo } from "react"
import { ChevronUp, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import type { Brick } from "@/lib/types"

type MintedBuild = {
  id: string
  name: string
  tokenId: number
  buildId?: string
  geoHash?: string
  bricks?: Brick[] // Make bricks optional to handle both embedded and lazy loading
}

const loadNFTBuildData = async (tokenId: number): Promise<Brick[] | null> => {
  try {
    console.log("[v0] Loading NFT build data for token:", tokenId)
    const response = await fetch(`/api/builds/token/${tokenId}`)

    console.log("[v0] Token API response status:", response.status, response.statusText)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Token API returned error:", {
        status: response.status,
        statusText: response.statusText,
        body: errorText,
        url: `/api/builds/token/${tokenId}`,
      })
      return null
    }

    const buildData = await response.json()
    console.log("[v0] NFT build data received:", {
      tokenId: buildData.tokenId,
      name: buildData.name,
      bricksCount: buildData.bricks?.length || 0,
      buildId: buildData.buildId,
    })

    const loadedBricks = buildData.bricks

    if (Array.isArray(loadedBricks) && loadedBricks.length > 0) {
      console.log("[v0] Loaded bricks array with", loadedBricks.length, "bricks")

      let minX = Number.POSITIVE_INFINITY,
        minY = Number.POSITIVE_INFINITY,
        minZ = Number.POSITIVE_INFINITY

      let maxX = Number.NEGATIVE_INFINITY,
        maxY = Number.NEGATIVE_INFINITY,
        maxZ = Number.NEGATIVE_INFINITY

      loadedBricks.forEach((b: Brick) => {
        minX = Math.min(minX, b.position[0])
        minY = Math.min(minY, b.position[1])
        minZ = Math.min(minZ, b.position[2])
        maxX = Math.max(maxX, b.position[0])
        maxY = Math.max(maxY, b.position[1])
        maxZ = Math.max(maxZ, b.position[2])
      })

      console.log("[v0] NFT Bounds Before Normalization:", {
        minX,
        maxX,
        rangeX: maxX - minX,
        minY,
        maxY,
        rangeY: maxY - minY,
        minZ,
        maxZ,
        rangeZ: maxZ - minZ,
        count: loadedBricks.length,
      })

      const uniqueYValues = [...new Set(loadedBricks.map((b: Brick) => b.position[1]))].sort((a, b) => a - b)
      console.log("[v0] Unique Y values (layers) in NFT:", uniqueYValues)

      const normalizedBricks = loadedBricks.map((b: Brick) => ({
        ...b,
        position: [Math.round(b.position[0] - minX), b.position[1] - minY, Math.round(b.position[2] - minZ)] as [
          number,
          number,
          number,
        ],
      }))

      const normalizedYValues = [...new Set(normalizedBricks.map((b: Brick) => b.position[1]))].sort((a, b) => a - b)
      console.log("[v0] Unique Y values after normalization:", normalizedYValues)

      console.log("[v0] Successfully normalized", normalizedBricks.length, "bricks to min corner (0,0,0)")
      return normalizedBricks
    }

    console.log("[v0] Returning empty bricks array")
    return loadedBricks
  } catch (error) {
    console.error("[v0] Error loading NFT build:", {
      error,
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      tokenId,
    })
    return null
  }
}

export default function V0BlocksV2({
  initialBaseWidth: baseWidth,
  initialBaseDepth: baseDepth,
  onResetBase,
  initialLoadedBuild,
  showLoadDialogImmediately,
  initialBricks,
  onAutoSave,
}: {
  initialBaseWidth: number
  initialBaseDepth: number
  onResetBase?: () => void
  initialLoadedBuild?: { name: string; bricks: Brick[] } | null
  showLoadDialogImmediately?: boolean
  initialBricks?: Brick[]
  onAutoSave?: (bricks: Brick[]) => void
}) {
  const { toast } = useToast()
  const [showNFTDrawer, setShowNFTDrawer] = useState(false)
  const [mintedBuilds, setMintedBuilds] = useState<MintedBuild[]>([])
  const [nftGeometry, setNftGeometry] = useState<Brick[] | null>(null)
  const [nftInfo, setNftInfo] = useState<{ tokenId: number; name: string; bricksCount: number } | null>(null)
  const [placedNFTs, setPlacedNFTs] = useState<
    Array<{ tokenId: number; name: string; bricksCount: number; brickIds: string[] }>
  >([])
  const [isNFTCounterExpanded, setIsNFTCounterExpanded] = useState(false)

  const nftCounts = useMemo(() => {
    const counts = new Map<number, { name: string; tokenId: number; bricksCount: number; count: number }>()

    placedNFTs.forEach((nft) => {
      const existing = counts.get(nft.tokenId)
      if (existing) {
        existing.count++
      } else {
        counts.set(nft.tokenId, { ...nft, count: 1 })
      }
    })

    return Array.from(counts.values())
  }, [placedNFTs])

  const nftComposition = useMemo(() => {
    const composition: Record<string, { count: number; name: string }> = {}
    placedNFTs.forEach((nft) => {
      const tokenId = nft.tokenId.toString()
      if (!composition[tokenId]) {
        composition[tokenId] = {
          count: 0,
          name: nft.name,
        }
      }
      composition[tokenId].count++
    })
    return composition
  }, [placedNFTs])

  useEffect(() => {
    console.log("[v0] V0BlocksV2 mounted")
    if (showNFTDrawer && mintedBuilds.length === 0) {
      fetchMintedBuilds()
    }
  }, [showNFTDrawer, mintedBuilds.length])

  const fetchMintedBuilds = async () => {
    console.log("[v0 PRODUCTION DEBUG] Starting fetchMintedBuilds...")
    console.log("[v0 PRODUCTION DEBUG] API URL:", "/api/builds/minted")

    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

      const response = await fetch("/api/builds/minted", {
        signal: controller.signal,
      }).finally(() => clearTimeout(timeoutId))

      console.log("[v0 PRODUCTION DEBUG] Response status:", response.status)
      console.log("[v0 PRODUCTION DEBUG] Response headers:", Object.fromEntries(response.headers.entries()))

      if (response.ok) {
        const data = await response.json()
        console.log("[v0 PRODUCTION DEBUG] Response data structure:", {
          hasBuilds: !!data.builds,
          buildsType: Array.isArray(data.builds) ? "array" : typeof data.builds,
          buildsLength: data.builds?.length,
          firstBuild: data.builds?.[0]
            ? {
                tokenId: data.builds[0].tokenId,
                name: data.builds[0].name,
                hasBricks: !!data.builds[0].bricks,
                bricksLength: data.builds[0].bricks?.length,
              }
            : null,
        })
        setMintedBuilds(data.builds || [])
      } else {
        const errorText = await response.text()
        console.error("[v0 PRODUCTION DEBUG] Failed to fetch:", {
          status: response.status,
          statusText: response.statusText,
          errorBody: errorText,
          url: "/api/builds/minted",
        })
        toast({
          title: "Failed to load NFTs",
          description: `HTTP ${response.status}: ${response.statusText}`,
          variant: "destructive",
        })
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        console.error("[v0 PRODUCTION DEBUG] Request timed out after 10 seconds")
        toast({
          title: "Request Timeout",
          description: "NFT loading took too long. Please try again.",
          variant: "destructive",
        })
      } else {
        console.error("[v0 PRODUCTION DEBUG] Fetch error:", {
          error,
          message: error instanceof Error ? error.message : String(error),
          stack: error instanceof Error ? error.stack : undefined,
          name: error instanceof Error ? error.name : "Unknown",
        })
        toast({
          title: "Failed to load NFTs",
          description: error instanceof Error ? error.message : "Unknown error",
          variant: "destructive",
        })
      }
    }
  }

  const handleNFTSelection = async (nft: MintedBuild) => {
    console.log("[v0 PRODUCTION DEBUG] NFT Selected:", {
      tokenId: nft.tokenId,
      name: nft.name,
      buildId: nft.buildId,
      hasBricksEmbedded: !!nft.bricks && nft.bricks.length > 0,
      bricksInList: nft.bricks?.length,
      bricksType: Array.isArray(nft.bricks) ? "array" : typeof nft.bricks,
      firstBrick: nft.bricks?.[0],
    })

    let nftBrickGeometry: Brick[] | null = null

    if (nft.bricks && Array.isArray(nft.bricks) && nft.bricks.length > 0) {
      console.log("[v0] Using embedded bricks for NFT:", nft.bricks.length, "bricks")
      nftBrickGeometry = nft.bricks
    } else {
      console.log("[v0] No embedded bricks, fetching separately for token:", nft.tokenId)
      nftBrickGeometry = await loadNFTBuildData(nft.tokenId)
    }

    if (nftBrickGeometry && nftBrickGeometry.length > 0) {
      console.log("[v0] ===== RAW NFT BRICK DATA BEFORE NORMALIZATION =====")
      console.log("[v0] Total bricks:", nftBrickGeometry.length)

      // Log ALL raw Y values to understand the vertical structure
      const rawYValues = nftBrickGeometry.map((b: Brick) => b.position[1])
      const uniqueRawYValues = [...new Set(rawYValues)].sort((a, b) => a - b)
      console.log("[v0] ALL raw Y values:", rawYValues)
      console.log("[v0] UNIQUE raw Y values (should show layers):", uniqueRawYValues)
      console.log("[v0] Number of unique Y levels (layers):", uniqueRawYValues.length)

      // Log first 5 bricks with full position data
      console.log("[v0] First 5 bricks (raw positions):")
      nftBrickGeometry.slice(0, 5).forEach((b, i) => {
        console.log(
          `[v0]   Brick ${i}: position=[${b.position.join(",")}], size=${b.width}x${b.depth}, color=${b.color}`,
        )
      })

      let minX = Number.POSITIVE_INFINITY,
        minY = Number.POSITIVE_INFINITY,
        minZ = Number.POSITIVE_INFINITY

      let maxX = Number.NEGATIVE_INFINITY,
        maxY = Number.NEGATIVE_INFINITY,
        maxZ = Number.NEGATIVE_INFINITY

      nftBrickGeometry.forEach((b: Brick) => {
        minX = Math.min(minX, b.position[0])
        minY = Math.min(minY, b.position[1])
        minZ = Math.min(minZ, b.position[2])
        maxX = Math.max(maxX, b.position[0])
        maxY = Math.max(maxY, b.position[1])
        maxZ = Math.max(maxZ, b.position[2])
      })

      console.log("[v0] NFT Bounds (Embedded Bricks):", {
        minX,
        maxX,
        rangeX: maxX - minX,
        minY,
        maxY,
        rangeY: maxY - minY,
        minZ,
        maxZ,
        rangeZ: maxZ - minZ,
        count: nftBrickGeometry.length,
      })

      if (uniqueRawYValues.length === 1) {
        console.warn("[v0] ⚠️ WARNING: All bricks have the SAME Y value! NFT appears flat.")
        console.warn("[v0] This means the vertical structure was NOT preserved when the NFT was saved.")
      }

      const normalizedBricks = nftBrickGeometry.map((b: Brick) => ({
        ...b,
        position: [Math.round(b.position[0] - minX), b.position[1] - minY, Math.round(b.position[2] - minZ)] as [
          number,
          number,
          number,
        ],
      }))

      const normalizedYValues = [...new Set(normalizedBricks.map((b: Brick) => b.position[1]))].sort((a, b) => a - b)
      console.log("[v0] ===== AFTER NORMALIZATION =====")
      console.log("[v0] Unique Y values after normalization:", normalizedYValues)
      console.log("[v0] First 5 normalized bricks:")
      normalizedBricks.slice(0, 5).forEach((b, i) => {
        console.log(`[v0]   Brick ${i}: position=[${b.position.join(",")}]`)
      })

      setNftGeometry(normalizedBricks)
      setNftInfo({ tokenId: nft.tokenId, name: nft.name, bricksCount: normalizedBricks.length })
      toast({
        title: "NFT Ready",
        description: `${nft.name || `Build #${nft.tokenId}`} loaded with ${uniqueRawYValues.length} layer(s). Click to place!`,
      })
    } else {
      console.error("[v0] Failed to load NFT geometry")
      toast({
        title: "Error",
        description: "Failed to load NFT build data",
        variant: "destructive",
      })
    }

    setShowNFTDrawer(false)
  }

  const handleNFTPlaced = (tokenId: number, name: string, bricksCount: number, brickIds: string[]) => {
    setPlacedNFTs((prev) => [...prev, { tokenId, name, bricksCount, brickIds }])
  }

  const handleBricksDeleted = (deletedBrickIds: string[]) => {
    // Count how many bricks of each NFT were deleted
    const nftDeleteCounts = new Map<number, number>()

    deletedBrickIds.forEach((id) => {
      const tokenId = placedNFTs.find((nft) => nft.brickIds.includes(id))?.tokenId
      if (tokenId !== undefined) {
        nftDeleteCounts.set(tokenId, (nftDeleteCounts.get(tokenId) || 0) + 1)
      }
    })

    // Remove NFT instances based on how many complete NFTs were deleted
    if (nftDeleteCounts.size > 0) {
      setPlacedNFTs((prev) => {
        const newPlacedNFTs = [...prev]
        nftDeleteCounts.forEach((deletedCount, tokenId) => {
          // Find the NFT entry
          const nftIndex = newPlacedNFTs.findIndex((nft) => nft.tokenId === tokenId)
          if (nftIndex !== -1) {
            const nft = newPlacedNFTs[nftIndex]
            // If all bricks of this instance were deleted, remove one instance
            if (deletedCount >= nft.bricksCount) {
              const instancesToRemove = Math.floor(deletedCount / nft.bricksCount)
              // Remove this many instances
              for (let i = 0; i < instancesToRemove; i++) {
                const idx = newPlacedNFTs.findIndex((n) => n.tokenId === tokenId)
                if (idx !== -1) newPlacedNFTs.splice(idx, 1)
              }
            }
          }
        })
        return newPlacedNFTs
      })
    }
  }

const handleBricksCleared = () => {
  setPlacedNFTs([])
  setNftGeometry(null)
  setNftInfo(null)
  }

  // Clear NFT mode when user switches back to regular brick controls
  const handleClearNFTMode = () => {
  if (nftGeometry) {
    setNftGeometry(null)
    setNftInfo(null)
  }
  }

  return (
    <div className="h-full w-full relative">
      <V0Blocks
        initialBaseWidth={baseWidth}
        initialBaseDepth={baseDepth}
        onResetBase={onResetBase}
        initialLoadedBuild={initialLoadedBuild}
        nftGeometry={nftGeometry}
        nftInfo={nftInfo}
        onNFTPlaced={handleNFTPlaced}
        onBricksCleared={handleBricksCleared}
        onBricksDeleted={handleBricksDeleted}
        nftComposition={nftComposition}
        initialBricks={initialBricks}
        onAutoSave={onAutoSave}
        onClearNFTMode={handleClearNFTMode}
        onOpenNFTBrowser={() => setShowNFTDrawer(true)}
      />

      

      <div className="absolute top-16 left-3 right-3 z-40 md:left-auto md:right-3 md:w-80">
        <div className="bg-[hsl(210,11%,18%)] backdrop-blur-lg rounded-xl border border-[hsl(210,8%,28%)] shadow-2xl overflow-hidden">
          {/* Header - always visible, clickable to toggle */}
          <button
            onClick={() => setIsNFTCounterExpanded(!isNFTCounterExpanded)}
            className="w-full p-3 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
          >
            <h3 className="text-white font-semibold text-sm flex items-center gap-2">
              <span>Placed NFTs</span>
              <Badge variant="secondary" className="bg-[#CDFD3E] text-black text-xs">
                {placedNFTs.length}
              </Badge>
            </h3>
            {isNFTCounterExpanded ? (
              <ChevronUp className="h-4 w-4 text-zinc-400" />
            ) : (
              <ChevronDown className="h-4 w-4 text-zinc-400" />
            )}
          </button>

          {/* Content - collapsible */}
          {isNFTCounterExpanded && (
            <div className="px-3 pb-3 max-h-48 overflow-y-auto">
              {nftCounts.length === 0 ? (
                <p className="text-zinc-400 text-center py-4">No NFTs placed yet</p>
              ) : (
                <div className="space-y-2">
                  {nftCounts.map((nft) => (
                    <div key={nft.tokenId} className="bg-black/30 rounded-lg p-3 border border-[hsl(210,8%,25%)]">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">
                            {nft.name} #{nft.tokenId}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <p className="text-sm text-zinc-400">{nft.bricksCount} bricks</p>
                            <span className="text-zinc-600">•</span>
                            <p className="text-[#CDFD3E] text-sm font-semibold">Count: {nft.count}</p>
                          </div>
                        </div>
                        <Badge variant="secondary" className="bg-[#CDFD3E] text-black">
                          #{nft.tokenId}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <Sheet open={showNFTDrawer} onOpenChange={setShowNFTDrawer}>
        <SheetContent side="left" className="w-[400px] bg-[#0a0a0a] border-[hsl(210,8%,28%)]">
          <SheetHeader>
            <SheetTitle className="text-white">Place NFT Builds</SheetTitle>
          </SheetHeader>
          <div className="mt-6 space-y-3 overflow-y-auto max-h-[calc(100vh-120px)]">
            {mintedBuilds.length === 0 ? (
              <p className="text-zinc-400 text-center py-8">Loading NFTs...</p>
            ) : (
              mintedBuilds.map((nft) => (
                <Card
                  key={nft.tokenId}
                  className="bg-[hsl(210,11%,15%)] border-[hsl(210,8%,28%)] cursor-pointer hover:border-[#CDFD3E] transition-colors"
                  onClick={() => handleNFTSelection(nft)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-white font-semibold">{nft.name || `Build #${nft.id.slice(0, 8)}`}</h3>
                        <div className="flex gap-2 mt-1">
                          <p className="text-sm text-zinc-400">{nft.bricks?.length || 0} bricks</p>
                          {nft.geoHash && <p className="text-xs text-zinc-500 font-mono">{nft.geoHash}</p>}
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-[#CDFD3E] text-black">
                        #{nft.tokenId}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
